### Basics of for loops ####

# A very basic for loop
# Try everything between the #### in a single block
####
for(i in 1:100)
{
	aa = i/100
	cat(aa, "\n")
}
####
# cat is R's "print to screen" command... "\n" means a line break

## Here's an example of how to use a for loop on last week's homework

# Read in marketmodel data
# marketmodel = read.csv("http://www2.mccombs.utexas.edu/faculty/james.scott/STA371G/Exercises_files/marketmodel.csv", header=TRUE)

n = nrow(marketmodel)

lmAAPL = lm(AAPL~SP500,data=marketmodel)
lmGOOG = lm(GOOG~SP500,data=marketmodel)
lmMRK = lm(MRK~SP500,data=marketmodel)
lmJNJ = lm(JNJ~SP500,data=marketmodel)
lmWMT = lm(WMT~SP500,data=marketmodel)
lmTGT = lm(TGT~SP500,data=marketmodel)

## Now look at the correlation among the residuals

# The following command creates a placeholder matrix of zeros
MMRes = matrix(0, nrow=n, ncol=6)

# Fill this in with residuals
MMRes[,1] = resid(lmAAPL)
MMRes[,2] = resid(lmGOOG)
MMRes[,3] = resid(lmMRK)
MMRes[,4] = resid(lmJNJ)
MMRes[,5] = resid(lmWMT)
MMRes[,6] = resid(lmTGT)

# Compute the sample correlation matrix
cor(MMRes)



# You could accomplish the same task with a "for" loop.
# This would far easier than the one-by-one approach above
# if you had a lot more than 6 things to look at.
# The downside is the mylm variable gets overwritten each time through the loop.

Dates = marketmodel[,1]
X = marketmodel[,2]
Y = marketmodel[,3:8]

Eps = matrix(0, nrow=n, ncol=6)
for(i in 1:6)
{
  # Regress each stock in turn on the market (X)
  # Notice how the variable i increments by 1 each time through
  mylm = lm(Y[,i]~X)
  Eps[,i] = resid(mylm)
}

# Eps is now a matrix of residuals
cor(Eps)

# The apply function is useful for calculating
# summaries along rows or columns
# This says calculate the standard deviation
# for each column (dimension 2)
apply(Eps,2,sd)



## Problem 1

# Load simdatasampand simdatapop
lm1 = lm(y~x, data = simdatasamp)
summary(lm1)

npop = nrow(simdatapop) 

# Take a single sample of size 50 from the population, and fit a regression line
nsamp = 50
mysample = sample(1:npop, size=nsamp)
lmsub = lm(y~x, data=simdatapop, subset = mysample)
coef(lmsub)


## Repeat this thousands of times inside a for loop!
## This code will execute the commands but not store the results.
## You fill in the rest... (placeholder matrix, writing the results
## each time through the for loop, etc.)
npop = nrow(simdatapop) 
nsamp = 50
for(i in 1:1000)
{
	mysample = sample(1:npop, size=nsamp)
	lmsub = lm(y~x, data=simdatapop, subset = mysample)
	coef(lmsub)
}


## Problem 2

# Need the mosaic library for this one!
# Make sure you load this first.
# If you don't, you are liable to get errors below.
library(mosaic)


data(Utilities)
plot(gasbill~temp,data=Utilities)


# Fit models
lm1 = lm(gasbill~temp,data=Utilities)
lm2 = lm(gasbill~temp+I(temp^2),data=Utilities)
# And so on for higher powers

# Plot and add fitted values
plot(gasbill~temp,data=Utilities)

# A different way to superimpose the linear fit
beta = coef(lm1)
curve(beta[1] + beta[2]*x, col='red', add=TRUE)

# Now the quadratic fit
beta = coef(lm2)	# This variable has now been over-written
curve(beta[1] + beta[2]*x + beta[3]*x^2, col='blue', add=TRUE)



## Cross validation
## A walk-through for a single train/test split

N = nrow(Utilities)
Ntrain = 59	## About 50% of the data used to train, 50% to test
Ntest = N - Ntrain

# Sample a training set
trainset = sample(1:N, Ntrain)

# Pick out the appropriate rows of the data frame for a training set
Util.train = Utilities[trainset,]

# And the rest of the rows for the test set
Util.test = Utilities[-trainset,]

# Fit models
lm1 = lm(gasbill~temp,data=Utilities)
lm2 = lm(gasbill~temp+I(temp^2),data=Utilities)

# make predictions for these models on the test set
pred1 = predict(lm1,newdata=Util.test)
pred2 = predict(lm2,newdata=Util.test)

# add up the squared errors
sse1 = sum((pred1 - Util.test$gasbill)^2)
sse2 = sum((pred2 - Util.test$gasbill)^2)




### Question 3

# Load the newspapers data
# First re-fit the least-squares model from last week

lm1 = lm(Sunday~Daily,data=newspapers)

# First try a single bootstrapped sample using the "resample" command
# Notice the difference from last week: we are re-sampling a sample,
# rather than sampling a population

lmboot = lm(Sunday~Daily,data=resample(newspapers))
coef(lmboot)

## Now use the do command and save the result
myboot = do(1000)*lm(Sunday~Daily,data=resample(newspapers))

sd(myboot)
hist(myboot)

## If you want some intuition for how the bootstrap behaves, try
## going back to the first problem and bootstrapping several
## different original samples from the wider population.
## Compare the bootstrapped standard errors with the true ones from
## sampling the actual population.