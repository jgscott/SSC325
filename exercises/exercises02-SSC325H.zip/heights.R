


#### In Galton's footsteps
# Read in data using Import Dataset, or...
#heights = read.csv("heights.csv")


lmM = lm(SHGT ~ MHGT, data=heights)
lmF = lm(SHGT ~ FHGT, data=heights)

# Get the means and standard deviations
colMeans(heights)

sd(heights)
# R will do this, but will object!  The following command
# accomplishes the same thing without R yelling at you
sapply(heights,sd)

# The attach() command allows R to see the variable names in heights
# without adding the "data = heights" option to all other commands
attach(heights)

par(mfrow=c(1,2))
plot(MHGT, SHGT, pch=19)
abline(lmM$coefficients)
plot(FHGT, SHGT, pch=19)
abline(lmF$coefficients)

par(mfrow=c(1,2))
plot(MHGT, lmM$residuals, pch=19, main="MHGT")
abline(lmM$coefficients)
plot(FHGT, lmF$residuals, pch=19, main="FHGT")
abline(lmF$coefficients)
